
document.addEventListener("DOMContentLoaded", async () => {
  try {
    await initConfig();
  } catch {
    alert("⚠️ Impossible de charger la configuration. Vérifiez que config.json est accessible.");
    return;
  }

  document.getElementById("btn-generer").addEventListener("click", generer);

  document.getElementById("n1").addEventListener("input", () =>
    liveValidate("n1", "tmoney", "hint-n1")
  );
  document.getElementById("n2").addEventListener("input", () =>
    liveValidate("n2", "flooz", "hint-n2")
  );

  // Vérification approbation au blur (quand l'utilisateur quitte le champ)
  document.getElementById("n1").addEventListener("blur", () =>
    checkApprovedLive("n1", "approved-n1")
  );
  document.getElementById("n2").addEventListener("blur", () =>
    checkApprovedLive("n2", "approved-n2")
  );
});

/* ---------- Validation format ---------- */
function liveValidate(inputId, network, hintId) {
  const val  = document.getElementById(inputId).value.trim();
  const hint = document.getElementById(hintId);
  // Réinitialiser le badge d'approbation si le numéro change
  const approvedHint = document.getElementById("approved-" + inputId);
  approvedHint.textContent   = "";
  approvedHint.style.display = "none";

  if (!val) { hint.style.display = "none"; return; }

  if (!validerNumero(val, network)) {
    hint.textContent = network === "tmoney"
      ? "❌ Doit commencer par 90/91/92/93/70/71/72 (8 chiffres)"
      : "❌ Doit commencer par 79/96/97/98/99 (8 chiffres)";
    hint.style.display = "block";
  } else {
    hint.style.display = "none";
  }
}

/* ---------- Vérification approbation live (/api/check-approved) ---------- */
async function checkApprovedLive(inputId, hintId) {
  const val  = document.getElementById(inputId).value.trim();
  const hint = document.getElementById(hintId);
  if (!val || val.length !== 8) return;

  hint.textContent   = "⏳ Vérification…";
  hint.style.color   = "#718096";
  hint.style.display = "block";

  try {
    const res  = await fetch(`/api/check-approved?phone=${encodeURIComponent(val)}`);
    const data = await res.json();

    if (data.approved) {
      hint.textContent = `✅ Numéro approuvé${data.user_name ? " · " + data.user_name : ""}`;
      hint.style.color = "#38a169";
    } else {
      hint.textContent  = "🚫 Numéro non approuvé — contactez l'administrateur.";
      hint.style.color  = "#e53e3e";
    }
  } catch {
    hint.textContent   = "";
    hint.style.display = "none";
  }
}

/* ---------- Génération du lien (/api/generate) ---------- */
async function generer() {
  const btn = document.getElementById("btn-generer");

  // 1. Lecture des champs
  const cli        = document.getElementById("numClient").value.trim();
  const mtBase     = Math.floor(parseFloat(document.getElementById("montant").value) || 0);
  const n1         = document.getElementById("n1").value.trim();
  const id1        = document.getElementById("id1").value.trim();
  const n2         = document.getElementById("n2").value.trim();
  const id2        = document.getElementById("id2").value.trim();
  const isEditable = document.getElementById("allowEdit").checked ? "1" : "0";
  const hasFrais   = document.getElementById("addFrais").checked  ? "1" : "0";
  const motif      = document.getElementById("motive").value.trim();

  // 2. Validations côté client
  if (!cli)       return alert("⚠️ Veuillez saisir le numéro WhatsApp du client.");
  if (!mtBase)    return alert("⚠️ Veuillez saisir un montant valide.");
  if (!n1 && !n2) return alert("⚠️ Veuillez saisir au moins un numéro de réception (Mixx ou Flooz).");

  if (n1 && !validerNumero(n1, "tmoney")) {
    return alert("❌ Numéro Mixx invalide (8 chiffres, préfixe 90/91/92/93/70/71/72).");
  }
  if (n2 && !validerNumero(n2, "flooz")) {
    return alert("❌ Numéro Flooz invalide (8 chiffres, préfixe 79/96/97/98/99).");
  }

  // 3. Calcul montant final
  const mtFinal = hasFrais === "1" ? Math.ceil(mtBase * 1.01) : mtBase;

  // 4. Appel /api/generate — l'auth se fait via les numéros approuvés côté serveur
  btn.disabled    = true;
  btn.textContent = "⏳ Génération en cours…";

  let lienFinal;
  try {
    const apiRes = await fetch(
      `/api/generate?${new URLSearchParams({
        mt: mtFinal,
        n1, id1, n2, id2,
        e: isEditable,
        f: hasFrais,
        motif,
      }).toString()}`
    );

    const data = await apiRes.json();

    if (!apiRes.ok || data.error) {
      throw new Error(data.error ?? "Erreur serveur");
    }

    lienFinal = data.url;
  } catch (err) {
    alert("❌ " + err.message);
    return;
  } finally {
    btn.disabled    = false;
    btn.textContent = "Générer le lien sécurisé";
  }

  // 5. Construction du message WhatsApp
  const montantFormate = formatMontant(mtFinal);
  const ligneMotif = motif ? `*Motif:* ${motif}\n` : "";
  const guideText =
    `\n*N°* *${n1}*  *${n2}*\n` +
    `*Id.* ${id1 || id2}\n` +
    `*Montant:* [ *${montantFormate}* ]\n` +
    ligneMotif +
    `_______________________\n` +
    `_*Cliquez sur le lien pour finaliser votre transfert.*_`;
  const msg = lienFinal + "\n" + guideText;

  // 6. Affichage résultat
  document.getElementById("resume").textContent = `Lien généré pour ${montantFormate}`;
  document.getElementById("waArea").innerHTML =
    `<a href="https://wa.me/${cli}?text=${encodeURIComponent(msg)}" target="_blank" class="wa-link">📲 Envoyer au client via WhatsApp</a>`;
  document.getElementById("result").style.display = "block";
  document.getElementById("result").scrollIntoView({ behavior: "smooth" });
}
