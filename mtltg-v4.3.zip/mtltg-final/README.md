# TransferLink v4.2 — Documentation

## Architecture

```
Vercel (Serverless Functions)   Supabase (PostgreSQL)
────────────────────────────    ─────────────────────
/api/generate.js                table: transfer_links
/api/verify.js                  table: approved_users
/api/approve.js
/api/users.js
/api/dashboard.js
```

## Pages

| Fichier                 | Rôle                                           |
|-------------------------|------------------------------------------------|
| index.html              | Interface admin de génération de liens          |
| transfer.html           | Page de paiement client (lien public)           |
| admin-users.html        | Approbation / révocation des utilisateurs       |
| admin-dashboard.html    | Suivi des liens, volumes, filtrages             |

## Variables d'environnement (Vercel)

```
ADMIN_PASS           code de sécurité admin (partagé toutes pages admin)
SECRET_KEY           clé AES-256 pour le chiffrement des liens
SUPABASE_URL         URL de votre projet Supabase
SUPABASE_SERVICE_KEY service_role key Supabase
BASE_URL             ex: https://mtl-tg.vercel.app
```

## Schéma Supabase

### Table existante : transfer_links — ajouter colonnes dénormalisées

```sql
ALTER TABLE transfer_links
  ADD COLUMN IF NOT EXISTS n1    TEXT,
  ADD COLUMN IF NOT EXISTS n2    TEXT,
  ADD COLUMN IF NOT EXISTS id1   TEXT,
  ADD COLUMN IF NOT EXISTS id2   TEXT,
  ADD COLUMN IF NOT EXISTS mt    TEXT,
  ADD COLUMN IF NOT EXISTS f     TEXT,
  ADD COLUMN IF NOT EXISTS motif TEXT;
```

### Nouvelle table : approved_users

```sql
CREATE TABLE approved_users (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone1      TEXT NOT NULL,
  phone2      TEXT,
  network     TEXT NOT NULL CHECK (network IN ('tmoney', 'flooz', 'both')),
  user_name   TEXT,
  notes       TEXT,
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked     BOOLEAN NOT NULL DEFAULT FALSE,
  revoked_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_approved_phone1 ON approved_users (phone1);
CREATE INDEX idx_approved_phone2 ON approved_users (phone2);
CREATE INDEX idx_approved_active ON approved_users (revoked, expires_at);

ALTER TABLE approved_users ENABLE ROW LEVEL SECURITY;
```

## Réseau Mobile Money — Togo

| Opérateur       | Label        | Préfixes                    |
|-----------------|--------------|-----------------------------|
| Togo Cellulaire | Mixx by Yas  | 90, 91, 92, 93, 70, 71, 72  |
| Moov            | Moov Flooz   | 79, 96, 97, 98, 99          |

Wave n'est pas disponible au Togo.
