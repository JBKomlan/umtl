/**
 * /api/dashboard.js — Données combinées pour le dashboard admin
 *
 * GET /api/dashboard?adminPass=...
 *   → { users: [...], links: [...] }
 *
 * Retourne tous les utilisateurs approuvés + tous les liens générés
 * pour affichage dans admin-dashboard.html
 */

export default async function handler(req, res) {
  const { adminPass } = req.query;

  if (!adminPass || adminPass !== process.env.ADMIN_PASS) {
    return res.status(401).json({ error: "Code admin incorrect." });
  }

  const base    = process.env.SUPABASE_URL;
  const headers = {
    "apikey"       : process.env.SUPABASE_SERVICE_KEY,
    "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
  };

  try {
    // Requêtes parallèles
    const [rUsers, rLinks] = await Promise.all([
      fetch(`${base}/rest/v1/approved_users?select=*&order=created_at.desc`, { headers }),
      fetch(`${base}/rest/v1/transfer_links?select=*&order=created_at.desc`, { headers }),
    ]);

    if (!rUsers.ok) throw new Error("Erreur approved_users : " + await rUsers.text());
    if (!rLinks.ok) throw new Error("Erreur transfer_links : " + await rLinks.text());

    // Les tokens sont chiffrés — on extrait les métadonnées utiles
    // (n1, n2, id1, id2, mt, f, e, motif) du payload si disponible,
    // sinon on renvoie juste id, created_at, expires_at
    const rawLinks = await rLinks.json();

    // Déchiffrement léger pour extraire les méta sans exposer le token complet
    const links = rawLinks.map(l => {
      // Les données opérationnelles sont dans la table directement si tu les dupliques,
      // sinon elles sont dans le token chiffré (non accessible ici sans la clé).
      // On expose uniquement ce qui est stocké en clair dans la table.
      return {
        id        : l.id,
        created_at: l.created_at,
        expires_at: l.expires_at,
        // Champs opérationnels — disponibles si tu as ajouté des colonnes dénormalisées
        // (voir note dans README). Sinon on renvoie null.
        n1    : l.n1    ?? null,
        n2    : l.n2    ?? null,
        id1   : l.id1   ?? null,
        id2   : l.id2   ?? null,
        mt    : l.mt    ?? null,
        motif : l.motif ?? null,
        f     : l.f     ?? null,
      };
    });

    return res.status(200).json({ users: await rUsers.json(), links });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
