/**
 * /api/check-approved.js — Vérification légère d'un numéro
 *
 * GET /api/check-approved?phone=90123456
 *   → { approved: true,  user_name: "Jean B." }
 *   → { approved: false }
 *
 * Utilisé par index.html pour le feedback visuel en temps réel.
 * Pas d'auth admin requise — retourne uniquement un booléen + nom.
 */

export default async function handler(req, res) {
  const { phone } = req.query;

  if (!phone || phone.length !== 8) {
    return res.status(400).json({ approved: false });
  }

  const url = `${process.env.SUPABASE_URL}/rest/v1/approved_users`
    + `?or=(phone1.eq.${phone},phone2.eq.${phone})`
    + `&revoked=eq.false`
    + `&expires_at=gt.${new Date().toISOString()}`
    + `&select=user_name`
    + `&limit=1`;

  try {
    const res2 = await fetch(url, {
      headers: {
        "apikey"       : process.env.SUPABASE_SERVICE_KEY,
        "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
      },
    });
    if (!res2.ok) throw new Error();
    const rows = await res2.json();
    if (rows.length > 0) {
      return res.status(200).json({ approved: true, user_name: rows[0].user_name ?? null });
    }
    return res.status(200).json({ approved: false });
  } catch {
    // En cas d'erreur Supabase, on ne bloque pas l'UI — la vérification finale
    // reste côté serveur dans /api/generate
    return res.status(200).json({ approved: false });
  }
}
