/**
 * /api/approve.js — Approbation et révocation des utilisateurs
 *
 * GET  /api/approve?adminPass=...&phone1=...&phone2=...&network=...&userName=...&notes=...&expires_at=...
 *        → active un utilisateur (INSERT dans approved_users)
 *
 * GET  /api/approve?adminPass=...&action=revoke&id=...
 *        → révoque un utilisateur (UPDATE revoked = true)
 */

/* ── Supabase helpers ── */
function sbHeaders() {
  return {
    "Content-Type" : "application/json",
    "apikey"       : process.env.SUPABASE_SERVICE_KEY,
    "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
  };
}

async function sbPost(table, body) {
  const url = `${process.env.SUPABASE_URL}/rest/v1/${table}`;
  const res = await fetch(url, {
    method : "POST",
    headers: { ...sbHeaders(), "Prefer": "return=minimal" },
    body   : JSON.stringify(body),
  });
  if (!res.ok) throw new Error(await res.text());
}

async function sbPatch(table, filter, body) {
  const url = `${process.env.SUPABASE_URL}/rest/v1/${table}?${filter}`;
  const res = await fetch(url, {
    method : "PATCH",
    headers: { ...sbHeaders(), "Prefer": "return=minimal" },
    body   : JSON.stringify(body),
  });
  if (!res.ok) throw new Error(await res.text());
}

/* ── Handler ── */
export default async function handler(req, res) {
  const { adminPass, action, id, phone1, phone2, network, userName, notes, expires_at } = req.query;

  // Auth
  if (!adminPass || adminPass !== process.env.ADMIN_PASS) {
    return res.status(401).json({ error: "Code admin incorrect." });
  }

  /* ── Révocation ── */
  if (action === "revoke") {
    if (!id) return res.status(400).json({ error: "ID requis pour la révocation." });
    try {
      await sbPatch("approved_users", `id=eq.${id}`, { revoked: true, revoked_at: new Date().toISOString() });
      return res.status(200).json({ ok: true });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  /* ── Approbation ── */
  if (!phone1 || !network || !expires_at) {
    return res.status(400).json({ error: "Paramètres manquants : phone1, network, expires_at requis." });
  }

  // Validation préfixes
  const PREFIXES = {
    tmoney: ["90","91","92","93","70","71","72"],
    flooz : ["96","97","98","99","79"],
  };
  const p1 = String(phone1).trim();
  if (p1.length !== 8) return res.status(400).json({ error: "phone1 doit faire 8 chiffres." });

  const nets = network === "both" ? ["tmoney"] : [network];
  const validNet = network === "both" ? PREFIXES.tmoney : PREFIXES[network];
  if (!validNet) return res.status(400).json({ error: "Réseau inconnu : " + network });
  if (!validNet.includes(p1.substring(0, 2))) {
    return res.status(400).json({ error: "Préfixe invalide pour " + network });
  }
  if (network === "both" && phone2) {
    const p2 = String(phone2).trim();
    if (p2.length !== 8 || !PREFIXES.flooz.includes(p2.substring(0, 2))) {
      return res.status(400).json({ error: "Numéro Flooz invalide." });
    }
  }

  // Expiration dans le futur
  if (new Date(expires_at) <= new Date()) {
    return res.status(400).json({ error: "La date d'expiration doit être dans le futur." });
  }

  try {
    await sbPost("approved_users", {
      phone1,
      phone2    : phone2 || null,
      network,
      user_name : userName || null,
      notes     : notes   || null,
      expires_at,
      revoked   : false,
      created_at: new Date().toISOString(),
    });
    return res.status(200).json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
