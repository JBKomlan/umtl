import crypto from "node:crypto";

const ALGO      = "aes-256-gcm";
const EXPIRY_MS = 30 * 24 * 60 * 60 * 1000; // 30 jours
const ID_LENGTH = 6; // longueur de l'identifiant court

/* ---------- Clé AES depuis SECRET_KEY ---------- */
function getKey() {
  const secret = process.env.SECRET_KEY;
  if (!secret) throw new Error("SECRET_KEY non définie.");
  return crypto.createHash("sha256").update(secret).digest();
}

/* ---------- Chiffrement AES-256-GCM ---------- */
function encrypt(payload) {
  const key    = getKey();
  const iv     = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, key, iv);
  const enc    = Buffer.concat([cipher.update(JSON.stringify(payload), "utf8"), cipher.final()]);
  const tag    = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64url");
}

/* ---------- Génère un ID court URL-safe ---------- */
function shortId(length = ID_LENGTH) {
  // base62 : 0-9 A-Z a-z  →  62^6 = ~56 milliards de combinaisons
  const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  const bytes = crypto.randomBytes(length);
  return Array.from(bytes).map(b => chars[b % chars.length]).join("");
}

/* ---------- Appel Supabase REST ---------- */
async function supabaseInsert(row) {
  const url = `${process.env.SUPABASE_URL}/rest/v1/transfer_links`;
  const res = await fetch(url, {
    method : "POST",
    headers: {
      "Content-Type" : "application/json",
      "apikey"       : process.env.SUPABASE_SERVICE_KEY,
      "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
      "Prefer"       : "return=minimal",
    },
    body: JSON.stringify(row),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Supabase insert error: ${err}`);
  }
}

/* ---------- Vérifie qu'un numéro est approuvé et non expiré ---------- */
async function checkApproved(phone) {
  if (!phone) return true; // champ optionnel ignoré
  const url = `${process.env.SUPABASE_URL}/rest/v1/approved_users`
    + `?or=(phone1.eq.${phone},phone2.eq.${phone})`
    + `&revoked=eq.false`
    + `&expires_at=gt.${new Date().toISOString()}`
    + `&select=id&limit=1`;
  const res = await fetch(url, {
    headers: {
      "apikey"       : process.env.SUPABASE_SERVICE_KEY,
      "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
    },
  });
  if (!res.ok) throw new Error("Erreur vérification approbation.");
  const rows = await res.json();
  return rows.length > 0;
}

/* ---------- Handler principal ---------- */
export default async function handler(req, res) {
  const {
    mt, n1 = "", id1 = "", n2 = "", id2 = "",
    e = "0", f = "0", motif = "",
  } = req.query;

  // 1. Paramètres obligatoires
  if (!mt || (!n1 && !n2)) {
    return res.status(400).json({ error: "Paramètres manquants : mt et au moins n1 ou n2 requis." });
  }

  // 2. ✅ Vérification approbation — les numéros sont le seul sésame
  try {
    if (n1 && !(await checkApproved(n1))) {
      return res.status(403).json({ error: `Le numéro ${n1} n'est pas approuvé ou son accès a expiré.` });
    }
    if (n2 && !(await checkApproved(n2))) {
      return res.status(403).json({ error: `Le numéro ${n2} n'est pas approuvé ou son accès a expiré.` });
    }
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  // 3. Payload → chiffrement
  const payload = { mt, n1, id1, n2, id2, e, f, motif, iat: Date.now() };
  let token;
  try {
    token = encrypt(payload);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  // 4. ID court + stockage Supabase (retry si collision)
  // Note : n1, n2, mt, motif sont dénormalisés pour le dashboard admin
  let linkId;
  for (let attempt = 0; attempt < 5; attempt++) {
    linkId = shortId();
    try {
      await supabaseInsert({
        id        : linkId,
        token,
        expires_at: new Date(Date.now() + EXPIRY_MS).toISOString(),
        // colonnes dénormalisées (à ajouter dans Supabase) pour le dashboard
        n1 : n1  || null,
        n2 : n2  || null,
        id1: id1 || null,
        id2: id2 || null,
        mt : mt  || null,
        f  : f,
        motif: motif || null,
      });
      break; // succès
    } catch (err) {
      if (attempt === 4) {
        return res.status(500).json({ error: "Impossible de générer un identifiant unique." });
      }
      // collision → on réessaie avec un nouvel ID
    }
  }

  // 5. URL courte finale
  const baseUrl = process.env.BASE_URL ?? "https://mtl-tg.vercel.app";
  const url = `${baseUrl}/transfer.html?id=${linkId}`;

  return res.status(200).json({ url });
}
