/**
 * /api/users.js — Liste des utilisateurs approuvés
 *
 * GET /api/users?adminPass=...
 *   → { users: [...] }
 *
 * Utilisé par admin-users.html et admin-dashboard.html
 */

export default async function handler(req, res) {
  const { adminPass } = req.query;

  if (!adminPass || adminPass !== process.env.ADMIN_PASS) {
    return res.status(401).json({ error: "Code admin incorrect." });
  }

  const url = `${process.env.SUPABASE_URL}/rest/v1/approved_users?select=*&order=created_at.desc`;
  try {
    const r = await fetch(url, {
      headers: {
        "apikey"       : process.env.SUPABASE_SERVICE_KEY,
        "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
      },
    });
    if (!r.ok) throw new Error(await r.text());
    const users = await r.json();
    return res.status(200).json({ users });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
